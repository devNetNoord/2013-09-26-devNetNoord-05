﻿using Microsoft.SPOT.Hardware;
using SecretLabs.NETMF.Hardware.Netduino;
using System.IO.Ports;
using System.Text;

namespace WirelessColors.Device
{
    public class Program
    {
        private static SerialPort _serialPort;
        private static PWM _ledR, _ledG, _ledB;

        public static void Main()
        {
            _serialPort = new SerialPort(SerialPorts.COM1, 9600, Parity.None, 8, StopBits.One);
            _serialPort.Open();

            _serialPort.DataReceived += serialPort_DataReceived;

            _ledR = new PWM(PWMChannels.PWM_PIN_D10, 100u, 0u, PWM.ScaleFactor.Microseconds, false);
            _ledG = new PWM(PWMChannels.PWM_PIN_D9, 100u, 0u, PWM.ScaleFactor.Microseconds, false);
            _ledB = new PWM(PWMChannels.PWM_PIN_D11, 100u, 0u, PWM.ScaleFactor.Microseconds, false);
            
            // Off
            _ledR.DutyCycle = 0;
            _ledG.DutyCycle = 0;
            _ledB.DutyCycle = 0;

            _ledR.Start();
            _ledG.Start();
            _ledB.Start();

            while (true)
            {
                // Keep running
            }
        }

        static void serialPort_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            var bytes = new byte[_serialPort.BytesToRead];
            var command = "";
            _serialPort.Read(bytes, 0, bytes.Length);

            var str = new string(Encoding.UTF8.GetChars(bytes));
            if (str == null || str.Length <= 0) return;

            if (str.IndexOf("|") <= -1) return;

            command += str.Substring(0, str.IndexOf("|"));

            var rgbValues = command.Split(',');
            if (rgbValues.Length != 3) return;

            _ledR.DutyCycle = (rgbValues[0] != "" ? int.Parse(rgbValues[0]) : 0) / 255d;
            _ledG.DutyCycle = (rgbValues[1] != "" ? int.Parse(rgbValues[1]) : 0) / 255d;
            _ledB.DutyCycle = (rgbValues[2] != "" ? int.Parse(rgbValues[2]) : 0) / 255d;
        }

    }
}
