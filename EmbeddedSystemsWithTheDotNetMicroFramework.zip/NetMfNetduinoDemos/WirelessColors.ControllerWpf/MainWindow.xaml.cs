﻿using System.IO.Ports;
using System.Text;
using System.Windows;
using System.Windows.Media;

namespace WirelessColors.ControllerWpf
{
    public partial class MainWindow : Elysium.Controls.Window
    {
        private SerialPort _serialPort;

        public MainWindow()
        {
            InitializeComponent();

            Loaded += MainWindow_Loaded;
        }

        void MainWindow_Loaded(object sender, RoutedEventArgs e)
        {
            _serialPort = new SerialPort("COM3", 9600, Parity.None, 8, StopBits.One);
            _serialPort.Open();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            var command = Encoding.UTF8.GetBytes(string.Format("{0},{1},{2}|", RedSlider.Value, GreenSlider.Value, BlueSlider.Value));
            if (_serialPort != null && _serialPort.IsOpen)
                _serialPort.Write(command, 0, command.Length);
        }

        private void Slider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            Preview.Fill = new SolidColorBrush(Color.FromRgb((byte)RedSlider.Value, (byte)GreenSlider.Value, (byte)BlueSlider.Value));
        }
    }
}
