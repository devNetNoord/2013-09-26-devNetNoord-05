﻿using FusionWare.SPOT.Hardware;
using MicroLiquidCrystal;
using Microsoft.SPOT.Hardware;
using System.Threading;

namespace HelloLcd
{
    public class Program
    {
        public static void Main()
        {
            // Initialize I2C bus (only one instance is allowed)
            var bus = new I2CBus();

            // Initialize provider (multiple devices can be attached to same bus)
            var lcdProvider = new MCP23008LcdTransferProvider(bus, 0x0, MCP23008LcdTransferProvider.DefaultSetup);

            // Create the LCD interface
            var lcd = new Lcd(lcdProvider);

            // Set up the LCD's number of columns and rows: 
            lcd.Begin(16, 2);
            lcd.Write("Hello LCD!");

            while (true)
            {
                // Set the cursor to column 0, line 1
                lcd.SetCursorPosition(0, 1);

                // Print the number of seconds since reset:
                lcd.Write((Utility.GetMachineTime().Ticks / 10000).ToString());

                Thread.Sleep(100);
            }
        }

    }
}
