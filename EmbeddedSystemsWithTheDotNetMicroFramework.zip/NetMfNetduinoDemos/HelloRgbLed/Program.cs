﻿using Microsoft.SPOT.Hardware;
using SecretLabs.NETMF.Hardware.Netduino;
using System.Threading;

namespace HelloRgbLed
{
    public class Program
    {
        private static PWM _ledR, _ledG, _ledB;
        private static readonly int[] Rgb = new int[3];

        public static void Main()
        {
            _ledR = new PWM(PWMChannels.PWM_PIN_D10, 100u, 0u, PWM.ScaleFactor.Microseconds, false);
            _ledG = new PWM(PWMChannels.PWM_PIN_D9, 100u, 0u, PWM.ScaleFactor.Microseconds, false);
            _ledB = new PWM(PWMChannels.PWM_PIN_D11, 100u, 0u, PWM.ScaleFactor.Microseconds, false);

            // Off
            _ledR.DutyCycle = 0;
            _ledG.DutyCycle = 0;
            _ledB.DutyCycle = 0;

            _ledR.Start();
            _ledG.Start();
            _ledB.Start();


            // Red
            _ledR.DutyCycle = 1;
            _ledG.DutyCycle = 0;
            _ledB.DutyCycle = 0;

            Thread.Sleep(500);

            // Green
            _ledR.DutyCycle = 0;
            _ledG.DutyCycle = 1;
            _ledB.DutyCycle = 0;

            Thread.Sleep(500);

            // Blue
            _ledR.DutyCycle = 0;
            _ledG.DutyCycle = 0;
            _ledB.DutyCycle = 1;

            Thread.Sleep(500);

            // White
            _ledR.DutyCycle = 1;
            _ledG.DutyCycle = 1;
            _ledB.DutyCycle = 1;

            Thread.Sleep(500);

            // Off
            _ledR.DutyCycle = 0;
            _ledG.DutyCycle = 0;
            _ledB.DutyCycle = 0;

            Thread.Sleep(2000);

            #region 
            // Unicorns
            Rgb[0] = 255;
            Rgb[1] = 0;
            Rgb[2] = 0;

            while (true)
            {
                for (var decColour = 0; decColour < 3; decColour += 1)
                {
                    var incColour = decColour == 2 ? 0 : decColour + 1;

                    for (var i = 0; i < 255; i += 1)
                    {
                        Rgb[decColour] -= 1;
                        Rgb[incColour] += 1;

                        _ledR.DutyCycle = Rgb[0] / 255D;
                        _ledG.DutyCycle = Rgb[1] / 255D;
                        _ledB.DutyCycle = Rgb[2] / 255D;

                        Thread.Sleep(1);
                    }
                }
            }
            #endregion
        }

    }
}
