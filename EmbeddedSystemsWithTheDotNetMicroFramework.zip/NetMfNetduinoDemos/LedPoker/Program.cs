﻿using Microsoft.SPOT.Hardware;
using SecretLabs.NETMF.Hardware.Netduino;

namespace LedPoker
{
    public class Program
    {
        public static void Main()
        {
            var button = new InputPort(Pins.ONBOARD_BTN, 
                false, Port.ResistorMode.Disabled);
            var led = new OutputPort(Pins.ONBOARD_LED, false);

            while (true)
            {
                led.Write(button.Read());
            }
        }

    }
}
