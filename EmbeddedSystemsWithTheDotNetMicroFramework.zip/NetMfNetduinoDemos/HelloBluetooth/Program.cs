﻿using Microsoft.SPOT.Hardware;
using SecretLabs.NETMF.Hardware.Netduino;
using System.IO.Ports;
using System.Text;
using System.Threading;

namespace HelloBluetooth
{
    public class Program
    {
        private static SerialPort _serialPort;

        public static void Main()
        {
            _serialPort = new SerialPort(SerialPorts.COM1, 9600, Parity.None, 8, StopBits.One);
            _serialPort.Open();

            while (true)
            {
                var message = Encoding.UTF8.GetBytes("Hello Bluetooth! " + (Utility.GetMachineTime().Ticks / 10000).ToString() + "\r");
                if (_serialPort.IsOpen)
                    _serialPort.Write(message, 0, message.Length);
                Thread.Sleep(100);
            }
        }

    }
}
