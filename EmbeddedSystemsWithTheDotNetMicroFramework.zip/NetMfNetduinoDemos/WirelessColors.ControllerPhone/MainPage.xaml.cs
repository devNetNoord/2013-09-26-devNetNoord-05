﻿using System.Text;
using Microsoft.Phone.Controls;
using System;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using Windows.Networking.Proximity;
using Windows.Networking.Sockets;
using Windows.Storage.Streams;

namespace WirelessColors.ControllerPhone
{
    public partial class MainPage : PhoneApplicationPage
    {
        private readonly StreamSocket _socket = new StreamSocket();

        public MainPage()
        {
            InitializeComponent();

            Loaded += async (s, e) =>
                {
                    PeerFinder.AlternateIdentities["Bluetooth:Paired"] = "";
                    var pairedDevices = await PeerFinder.FindAllPeersAsync();

                    if (pairedDevices.Count == 0) return;
                    var linvor = pairedDevices.FirstOrDefault(pairedDevice => pairedDevice.DisplayName == "linvor");

                    if (linvor == null) return;
                    await _socket.ConnectAsync(linvor.HostName, "1");
                };
        }

        private void Slider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            ((Slider)sender).Value = (int)e.NewValue;
            Preview.Fill = new SolidColorBrush(Color.FromArgb(0xff, (byte)RedSlider.Value, (byte)GreenSlider.Value, (byte)BlueSlider.Value));
        }

        private async void Button_Click(object sender, RoutedEventArgs e)
        {
            var commandString = string.Format("{0},{1},{2}|", RedSlider.Value, GreenSlider.Value, BlueSlider.Value);
            var dataBuffer = GetBufferFromByteArray(Encoding.UTF8.GetBytes(commandString));
            await _socket.OutputStream.WriteAsync(dataBuffer);
        }

        private static IBuffer GetBufferFromByteArray(byte[] package)
        {
            using (var dw = new DataWriter())
            {
                dw.WriteBytes(package);
                return dw.DetachBuffer();
            }
        }
    }
}